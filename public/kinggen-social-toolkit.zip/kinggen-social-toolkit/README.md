# KingGen Ministries Social Media Toolkit

Brand assets and templates for KingGen Ministries social media content.

## Contents

### Backgrounds
- `backgrounds/` - Social media background templates
  - Green branded backgrounds with cross motif
  - Light/neutral backgrounds for text overlay
  - Story format (9:16) and post format (1:1) variants

## Brand Colors
- **Primary Green**: Deep forest green (#1B4332 approximate)
- **Accent Gold**: Warm gold highlights
- **Neutral Light**: Off-white/light gray for contrast

## Usage
These backgrounds are designed for:
- Instagram posts and stories
- Facebook content
- General social media graphics

Add text, quotes, scripture, or announcements over these branded backgrounds in Canva or your preferred design tool.

## About KingGen Ministries
Gospel-centered Christian counseling services.

---
*November 2025 Toolkit*
